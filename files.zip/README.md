# Discord Bot Builder - دليل التثبيت والتشغيل

## 📋 المتطلبات

1. **Node.js** (الإصدار 16 أو أحدث)
   - تحميل من: https://nodejs.org/

2. **Discord Bot Token**
   - اذهب إلى: https://discord.com/developers/applications
   - أنشئ Application جديد
   - اذهب إلى Bot → Reset Token
   - انسخ التوكن

3. **Bot Permissions**
   - في صفحة OAuth2 → URL Generator
   - اختر: `bot` و `applications.commands`
   - Permissions: `Administrator` (أو حسب الحاجة)
   - انسخ الرابط وأضف البوت لسيرفرك

## 🚀 خطوات التثبيت

### 1. تثبيت المكتبات

```bash
npm install
```

هذا الأمر سيثبت:
- discord.js (v14) - مكتبة الديسكورد الرسمية
- express - السيرفر
- body-parser - معالجة البيانات
- cors - السماح بالطلبات من المتصفح

### 2. تشغيل السيرفر

```bash
npm start
```

أو للتطوير مع إعادة التشغيل التلقائي:

```bash
npm run dev
```

### 3. فتح الموقع

افتح المتصفح على:
```
http://localhost:3000
```

## 📝 كيفية الاستخدام

### خطوة 1: إدخال التوكن
1. ضع توكن البوت في خانة "Discord Bot Token"
2. لن تحتاج للضغط على أي زر - البوت سيتصل تلقائياً

### خطوة 2: إضافة أوامر
1. **اسم الأمر**: اكتب اسم الأمر بدون `/` (مثال: welcome)
2. **رد البوت**: الرسالة اللي هيردها البوت
3. **وصف الأمر**: وصف مختصر (اختياري)
4. **كود إضافي**: JavaScript code يشتغل مع الأمر (اختياري)
5. اضغط "إضافة الأمر ونشره"

### خطوة 3: استخدام الأوامر في الديسكورد
1. اذهب لسيرفر الديسكورد
2. اكتب `/` في أي قناة
3. اختر الأمر من القائمة
4. البوت سيرد تلقائياً!

## 💡 أمثلة على الأوامر

### مثال 1: أمر ترحيب بسيط
```
اسم الأمر: welcome
رد البوت: أهلاً بك في السيرفر! 👋
```

### مثال 2: أمر مع كود إضافي
```
اسم الأمر: announce
رد البوت: تم إرسال الإعلان!
الكود الإضافي:
const channel = interaction.guild.channels.cache.find(c => c.name === 'announcements');
if (channel) {
    channel.send('🔔 إعلان جديد من الإدارة!');
}
```

### مثال 3: أمر يعطي رول
```
اسم الأمر: verify
رد البوت: تم التحقق منك بنجاح! ✅
الكود الإضافي:
const role = interaction.guild.roles.cache.find(r => r.name === 'Verified');
if (role) {
    await interaction.member.roles.add(role);
}
```

## 🔧 الإعدادات المتقدمة

### تشغيل البوت 24/7

لتشغيل البوت بشكل دائم، استخدم:

**على السيرفر المحلي:**
```bash
npm install -g pm2
pm2 start server.js --name discord-bot-builder
pm2 save
pm2 startup
```

**على السحابة (Cloud):**
- Heroku
- Railway
- Render
- DigitalOcean

### متغيرات البيئة (اختياري)

أنشئ ملف `.env`:
```
PORT=3000
NODE_ENV=production
```

## 📊 الميزات

✅ **نشر تلقائي**: الأوامر تُنشر فوراً على الديسكورد
✅ **حفظ تلقائي**: البيانات تُحفظ تلقائياً
✅ **إعادة اتصال تلقائي**: البوتات تعيد الاتصال عند إعادة تشغيل السيرفر
✅ **أكواد مخصصة**: إضافة JavaScript لأي وظيفة
✅ **سجل مباشر**: متابعة كل العمليات
✅ **متعدد المستخدمين**: كل مستخدم له بوتاته الخاصة

## ⚠️ ملاحظات مهمة

1. **لا تشارك التوكن**: التوكن سري ويعطي تحكم كامل بالبوت
2. **Intents**: تأكد من تفعيل الـ Intents في Discord Developer Portal:
   - SERVER MEMBERS INTENT
   - MESSAGE CONTENT INTENT
3. **Rate Limits**: لا تضيف أكثر من 100 أمر دفعة واحدة
4. **الأمان**: في الإنتاج، استخدم HTTPS ونظام مصادقة حقيقي

## 🐛 حل المشاكل

### البوت لا يتصل
- تأكد من صحة التوكن
- تأكد من تفعيل Intents في Developer Portal
- تحقق من الـ Bot Permissions

### الأوامر لا تظهر في الديسكورد
- انتظر 1-5 دقائق (قد يستغرق وقتاً للتحديث)
- أعد تشغيل السيرفر
- تأكد من أن البوت في السيرفر

### الكود الإضافي لا يعمل
- تحقق من syntax errors
- استخدم `console.log()` للتنقيح
- تحقق من Permissions اللازمة

## 📞 الدعم

- Discord.js Documentation: https://discord.js.org/
- Discord Developer Portal: https://discord.com/developers/docs

## 🔄 التحديثات المستقبلية

- [ ] نظام مصادقة كامل
- [ ] واجهة إدارة متقدمة
- [ ] دعم Buttons & Select Menus
- [ ] Analytics & Statistics
- [ ] نظام Templates للأوامر
- [ ] دعم Multiple Languages

---

صنع بـ ❤️ لمجتمع الديسكورد العربي
