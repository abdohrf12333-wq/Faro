// server.js - Backend Server for Discord Bot Builder
const express = require('express');
const { Client, GatewayIntentBits, REST, Routes, SlashCommandBuilder } = require('discord.js');
const bodyParser = require('body-parser');
const cors = require('cors');
const fs = require('fs').promises;
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(bodyParser.json());
app.use(express.static('public'));

// Store active bot instances
const activeBots = new Map();
const DATABASE_FILE = path.join(__dirname, 'database.json');

// Load database
async function loadDatabase() {
    try {
        const data = await fs.readFile(DATABASE_FILE, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        return { users: {} };
    }
}

// Save database
async function saveDatabase(data) {
    await fs.writeFile(DATABASE_FILE, JSON.stringify(data, null, 2));
}

// Create Discord bot instance
async function createBot(token, commands, userId) {
    try {
        // Stop existing bot if any
        if (activeBots.has(userId)) {
            const oldBot = activeBots.get(userId);
            oldBot.destroy();
        }

        const client = new Client({
            intents: [
                GatewayIntentBits.Guilds,
                GatewayIntentBits.GuildMessages,
                GatewayIntentBits.MessageContent,
                GatewayIntentBits.GuildMembers
            ]
        });

        // Register slash commands
        client.once('ready', async () => {
            console.log(`✅ Bot logged in as ${client.user.tag} for user ${userId}`);

            try {
                // Prepare slash commands
                const slashCommands = commands.map(cmd => {
                    return new SlashCommandBuilder()
                        .setName(cmd.name.toLowerCase().replace(/[^a-z0-9_-]/g, ''))
                        .setDescription(cmd.description || 'No description')
                        .toJSON();
                });

                const rest = new REST({ version: '10' }).setToken(token);

                // Register commands globally
                await rest.put(
                    Routes.applicationCommands(client.user.id),
                    { body: slashCommands }
                );

                console.log(`✅ Successfully registered ${commands.length} slash commands`);
            } catch (error) {
                console.error('❌ Error registering commands:', error);
            }
        });

        // Handle slash command interactions
        client.on('interactionCreate', async interaction => {
            if (!interaction.isChatInputCommand()) return;

            const command = commands.find(cmd => 
                cmd.name.toLowerCase().replace(/[^a-z0-9_-]/g, '') === interaction.commandName
            );

            if (!command) return;

            try {
                // Send the reply
                await interaction.reply(command.reply);

                // Execute additional code if exists
                if (command.code && command.code.trim()) {
                    try {
                        // Create safe execution context
                        const AsyncFunction = Object.getPrototypeOf(async function(){}).constructor;
                        const executeCode = new AsyncFunction('interaction', 'client', command.code);
                        await executeCode(interaction, client);
                    } catch (codeError) {
                        console.error('Error executing custom code:', codeError);
                    }
                }
            } catch (error) {
                console.error('Error handling interaction:', error);
                if (!interaction.replied) {
                    await interaction.reply({ content: 'حدث خطأ أثناء تنفيذ الأمر', ephemeral: true });
                }
            }
        });

        // Login bot
        await client.login(token);
        
        // Store bot instance
        activeBots.set(userId, client);

        return {
            success: true,
            message: 'Bot connected successfully',
            botTag: client.user.tag,
            commandsRegistered: commands.length
        };

    } catch (error) {
        console.error('Error creating bot:', error);
        return {
            success: false,
            message: error.message || 'Failed to connect bot'
        };
    }
}

// API Endpoints

// Connect bot
app.post('/api/bot/connect', async (req, res) => {
    try {
        const { userId, token, commands } = req.body;

        if (!userId || !token || !commands) {
            return res.status(400).json({ error: 'Missing required fields' });
        }

        const result = await createBot(token, commands, userId);
        
        if (result.success) {
            // Save to database
            const db = await loadDatabase();
            if (!db.users[userId]) {
                db.users[userId] = {};
            }
            db.users[userId].token = token;
            db.users[userId].commands = commands;
            db.users[userId].lastConnected = new Date().toISOString();
            await saveDatabase(db);
        }

        res.json(result);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Update commands
app.post('/api/bot/update-commands', async (req, res) => {
    try {
        const { userId, commands } = req.body;

        if (!userId || !commands) {
            return res.status(400).json({ error: 'Missing required fields' });
        }

        const db = await loadDatabase();
        if (!db.users[userId] || !db.users[userId].token) {
            return res.status(400).json({ error: 'No active bot found' });
        }

        // Reconnect bot with new commands
        const result = await createBot(db.users[userId].token, commands, userId);
        
        if (result.success) {
            db.users[userId].commands = commands;
            db.users[userId].lastUpdated = new Date().toISOString();
            await saveDatabase(db);
        }

        res.json(result);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get bot status
app.get('/api/bot/status/:userId', async (req, res) => {
    try {
        const { userId } = req.params;
        const isActive = activeBots.has(userId);
        
        let status = {
            connected: isActive,
            commandsCount: 0
        };

        if (isActive) {
            const bot = activeBots.get(userId);
            const db = await loadDatabase();
            status.botTag = bot.user.tag;
            status.commandsCount = db.users[userId]?.commands?.length || 0;
        }

        res.json(status);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Save user data
app.post('/api/user/save', async (req, res) => {
    try {
        const { userId, email, commands, token } = req.body;

        const db = await loadDatabase();
        db.users[userId] = {
            email,
            commands,
            token,
            lastSaved: new Date().toISOString()
        };
        await saveDatabase(db);

        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Load user data
app.get('/api/user/load/:userId', async (req, res) => {
    try {
        const { userId } = req.params;
        const db = await loadDatabase();
        const userData = db.users[userId] || null;

        res.json(userData);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Disconnect bot
app.post('/api/bot/disconnect', async (req, res) => {
    try {
        const { userId } = req.body;

        if (activeBots.has(userId)) {
            const bot = activeBots.get(userId);
            bot.destroy();
            activeBots.delete(userId);
            res.json({ success: true, message: 'Bot disconnected' });
        } else {
            res.json({ success: false, message: 'No active bot found' });
        }
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Auto-reconnect bots on server start
async function autoReconnectBots() {
    try {
        const db = await loadDatabase();
        console.log('🔄 Auto-reconnecting saved bots...');

        for (const [userId, userData] of Object.entries(db.users)) {
            if (userData.token && userData.commands && userData.commands.length > 0) {
                console.log(`Reconnecting bot for user: ${userId}`);
                await createBot(userData.token, userData.commands, userId);
                // Wait a bit between connections to avoid rate limits
                await new Promise(resolve => setTimeout(resolve, 2000));
            }
        }

        console.log('✅ Auto-reconnect complete');
    } catch (error) {
        console.error('Error auto-reconnecting bots:', error);
    }
}

// Start server
app.listen(PORT, async () => {
    console.log(`🚀 Server running on port ${PORT}`);
    console.log(`📡 API available at http://localhost:${PORT}/api`);
    
    // Auto-reconnect bots after server starts
    setTimeout(autoReconnectBots, 3000);
});

// Graceful shutdown
process.on('SIGINT', () => {
    console.log('\n🛑 Shutting down...');
    
    // Disconnect all bots
    for (const [userId, bot] of activeBots) {
        console.log(`Disconnecting bot for user: ${userId}`);
        bot.destroy();
    }
    
    process.exit(0);
});

module.exports = app;
